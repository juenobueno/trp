package therobotpeople.urcap;

import java.awt.Point;
import java.util.ArrayList;

public class Selector {
	public static String selected = "";
	public static int count = 0;
	public static ArrayList<Point> point_list = new ArrayList<Point>();
}
